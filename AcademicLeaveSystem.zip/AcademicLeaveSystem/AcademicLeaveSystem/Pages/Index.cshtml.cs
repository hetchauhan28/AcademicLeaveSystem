﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AcademicLeaveSystem.Pages
{
    public class IndexModel : PageModel
    {
        public string StudentName { get; set; } = "";

        public string SelectedDate { get; set; } = "";

        public List<AcademicEvent> Events { get; set; } = new List<AcademicEvent>();

        public void OnGet()
        {
            StudentName = HttpContext.Session.GetString("UserID") ?? "Student";

            SelectedDate = HttpContext.Session.GetString("SelectedDate") ?? "";

            Events = new List<AcademicEvent>
            {
                new AcademicEvent
                {
                    Date = "15/08/2026",
                    EventName = "Independence Day",
                    Description = "College Holiday"
                },

                new AcademicEvent
                {
                    Date = "05/09/2026",
                    EventName = "Teachers' Day",
                    Description = "College Event"
                },

                new AcademicEvent
                {
                    Date = "02/10/2026",
                    EventName = "Gandhi Jayanti",
                    Description = "College Holiday"
                },

                new AcademicEvent
                {
                    Date = "15/10/2026",
                    EventName = "Mid-Term Examination",
                    Description = "Mid-term examination"
                },

                new AcademicEvent
                {
                    Date = "14/11/2026",
                    EventName = "Children's Day",
                    Description = "College Event"
                },

                new AcademicEvent
                {
                    Date = "01/12/2026",
                    EventName = "End Semester Examination",
                    Description = "Final examination"
                }
            };
        }

        public IActionResult OnPostApplyLeave(string selectedDate)
        {
            HttpContext.Session.SetString("SelectedDate", selectedDate);

            return RedirectToPage("/Leave");
        }
    }

    public class AcademicEvent
    {
        public string Date { get; set; } = "";

        public string EventName { get; set; } = "";

        public string Description { get; set; } = "";
    }
}