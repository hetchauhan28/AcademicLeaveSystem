﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AcademicLeaveSystem.Pages
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        public string UserId { get; set; }

        [BindProperty]
        public string Password { get; set; }

        [BindProperty]
        public bool RememberMe { get; set; }

        public string ErrorMessage { get; set; }

        public void OnGet()
        {
            if (Request.Cookies.ContainsKey("UserID"))
            {
                UserId = Request.Cookies["UserID"];
                RememberMe = true;
            }
        }

        public IActionResult OnPost()
        {
            if (UserId == "Student" && Password == "1234")
            {
                HttpContext.Session.SetString("UserID", UserId);

                if (RememberMe)
                {
                    Response.Cookies.Append(
                        "UserID",
                        UserId,
                        new CookieOptions
                        {
                            Expires = DateTime.Now.AddDays(30),
                            HttpOnly = true
                        });
                }

                return RedirectToPage("/Index");
            }

            ErrorMessage = "Invalid User ID or Password.";

            return Page();
        }
    }
}
