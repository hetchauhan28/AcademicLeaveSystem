﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Text.Json;

namespace AcademicLeaveSystem.Pages
{
    public class LeaveModel : PageModel
    {
        public string StudentName { get; set; }

        [BindProperty]
        public LeaveApplication Application { get; set; }

        public List<LeaveApplication> LeaveApplications { get; set; }

        public void OnGet()
        {
            LoadPage();
        }

        public IActionResult OnGetHistory()
        {
            LoadPage();

            return Page();
        }

        public IActionResult OnPost()
        {
            StudentName =
                HttpContext.Session.GetString("UserID");

            if (string.IsNullOrEmpty(StudentName))
            {
                return RedirectToPage("/Login");
            }

            if (!ModelState.IsValid)
            {
                return Page();
            }

            string data =
                HttpContext.Session.GetString(
                    "LeaveApplications");

            List<LeaveApplication> leaves;

            if (string.IsNullOrEmpty(data))
            {
                leaves = new List<LeaveApplication>();
            }
            else
            {
                leaves =
                    JsonSerializer.Deserialize<
                        List<LeaveApplication>>(data);
            }

            Application.Id = leaves.Count + 1;

            Application.Status = "Pending";

            Application.AppliedOn = DateTime.Now;

            leaves.Add(Application);

            HttpContext.Session.SetString(
                "LeaveApplications",
                JsonSerializer.Serialize(leaves));

            return RedirectToPage(
                "/Leave",
                new { handler = "History" });
        }

        private void LoadPage()
        {
            StudentName =
                HttpContext.Session.GetString("UserID");

            if (string.IsNullOrEmpty(StudentName))
            {
                Response.Redirect("/Login");
                return;
            }

            Application = new LeaveApplication();

            Application.StudentName = StudentName;

            string selectedDate =
                HttpContext.Session.GetString(
                    "SelectedDate");

            if (!string.IsNullOrEmpty(selectedDate))
            {
                Application.FromDate =
                    DateTime.Parse(selectedDate);

                Application.ToDate =
                    DateTime.Parse(selectedDate);
            }

            string data =
                HttpContext.Session.GetString(
                    "LeaveApplications");

            if (string.IsNullOrEmpty(data))
            {
                LeaveApplications =
                    new List<LeaveApplication>();
            }
            else
            {
                LeaveApplications =
                    JsonSerializer.Deserialize<
                        List<LeaveApplication>>(data);
            }
        }
    }

    public class LeaveApplication
    {
        public int Id { get; set; }

        public string StudentName { get; set; }

        public string LeaveType { get; set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public string Reason { get; set; }

        public string WorkloadPlan { get; set; }

        public string Status { get; set; }

        public DateTime AppliedOn { get; set; }
    }
}